   
import streamlit as st
import pandas as pd
import numpy as np
import pickle
from sklearn.preprocessing import StandardScaler

# Load your trained model
model = pickle.load(open('model.pkl', 'rb'))
scaler = pickle.load(open('scaler.pkl', 'rb'))
top_features = pickle.load(open('features.pkl', 'rb')) 

# Create inputs for user to enter values
st.title('Customer Churn Prediction')

monthly_charges = st.number_input("Enter Monthly Charges")
total_charges = st.number_input("Enter Total Charges")
contract_month_to_month = st.selectbox("Is the customer's contract month-to-month?", ('Yes', 'No'))
tenure = st.number_input("Enter tenure")
internet_service_fiber_optic = st.selectbox('Does the customer use fiber optic internet service?', ('Yes', 'No'))
dependents = st.selectbox('Does the customer have dependents?', ('Yes', 'No'))
senior_citizen = st.selectbox('Is the customer a senior citizen?', ('Yes', 'No'))
partner = st.selectbox('Does the customer have a partner?', ('Yes', 'No'))

# Convert categorical variables to binary
contract_month_to_month = 1 if contract_month_to_month == 'Yes' else 0
internet_service_fiber_optic = 1 if internet_service_fiber_optic == 'Yes' else 0
dependents = 1 if dependents == 'Yes' else 0
senior_citizen = 1 if senior_citizen == 'Yes' else 0
partner = 1 if partner == 'Yes' else 0

# Button to make prediction
if st.button('Predict'):
    # Collect inputs in a dataframe or array
    data = {'MonthlyCharges': monthly_charges, 
            'TotalCharges': total_charges, 
            'Contract_Month-to-month': contract_month_to_month,
            'tenure': tenure,
            'InternetService_Fiber optic': internet_service_fiber_optic,
            'SeniorCitizen': senior_citizen,
            'Dependents_Yes': dependents,
            'Partner_Yes' : partner
            }
    df = pd.DataFrame(data, index=[0])
    
    # Scale the data
    df_scaled = scaler.transform(df)
    
    
    # Subset the data after scaling
    #df_subset = df_scaled[top_features]  # Assuming top_features is a list of your top feature names

        # Get prediction probability
    prediction_proba = model.predict(df_scaled)[0]

    # Convert probability to class label
    prediction = 1 if prediction_proba > 0.5 else 0
    


    # Display prediction and confidence factor
    if prediction == 0:
        st.write('The customer is not likely to churn.')
    else:
        st.write('The customer is likely to churn.')
            # Calculate confidence level
    confidence = prediction_proba if prediction == 1 else 1 - prediction_proba

    # Display prediction and confidence level
    st.write(f'Prediction: {prediction_proba[0]:.2f}')
    st.write(f'Confidence: {confidence[0]*100:.2f}%')
    
    

